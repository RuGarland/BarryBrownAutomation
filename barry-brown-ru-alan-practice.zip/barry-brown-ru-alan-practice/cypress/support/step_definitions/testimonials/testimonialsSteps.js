/// <reference types="Cypress" />

import { Given, When, Then, Before } from "@badeball/cypress-cucumber-preprocessor";
import { TestimonialsPageElements } from "../../../pages/testimonialsPage";

Before({ tags: "@fixture-required" }, function()
{
    cy.fixture("testimonialsData")
        .then(function(data)
        {
            this.testimonialData = data;
        });
});


When("the user selects the 'testimonials' link from the nav bar", function() 
{
    cy.get("a")
        .contains("Testimonials")
        .click();
});

Then("the 'testimonials' page is displayed", function()
{
    cy.get(TestimonialsPageElements.pageHeader)
        .invoke("text")
        .should("equal", "Testimonials");
});


Given("the user is on the 'testimonials' page", function()
{
    cy.visit("/testimonials");
});

Then("there are 4 testimonials present", function()
{
    cy.get("blockquote")
        .should("have.length", 4);
});


Given("all testimonials are present", function()
{
    cy.get("blockquote")
        .should("have.length", 4);
});

Then("the testimonials are in the correct order", function()
{
    cy.get(TestimonialsPageElements.testimonialAuthors)
        .each(($el, index) =>
        {
            let val = this.testimonialData.expectedOrder[index];

            expect($el.text()).to.equal(val);
        });
});

Then("each testimonial has the correct content", function()
{
    cy.get(TestimonialsPageElements.testimonialQuotes)
        .each(($el, index) =>
        {
            let val = this.testimonialData.expectedContent[index];

            expect($el.text()).to.contain(val);
        });
});
