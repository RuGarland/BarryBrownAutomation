import { Given, When, Then, DataTable, AfterAll, Background, Before } from "@badeball/cypress-cucumber-preprocessor";
import { homePageLocators } from "../../../pages/homePage";

Before({tags: "@HomeF"}, function() {
    cy.fixture('homePagesData.json').then((data) => {
        this.homeData = data;
    });
    cy.fixture('servicesFixture.json').then((data) => {
        this.servicesData = data;
    });
});


Given("the user can access the Homepage", () => {
    cy.visit("/")
})

When("the user confirms page has loaded", function() {
    cy.get(homePageLocators.homePageheader).contains("Are you planning an improvement")
})

When("Checks the Logo", () => {
    cy.get(homePageLocators.logoImage).click()
})

When("Checks the page contents", function(){
    cy.get(homePageLocators.homePageImage).should("be.visible")
    cy.get(homePageLocators.homePageAdvice).contains(this.homeData.homePageAdvice)
    cy.get(homePageLocators.homePageThink).contains(this.homeData.tGreen)    
})

When("the user checks the Footer Link for contact us", function(){
    cy.get(homePageLocators.footerContactUs).eq(0).contains(this.homeData.contactForm).click()
    cy.get(homePageLocators.pageTitle).contains("Contact")
})

When("the user Checks Privacy Policy", function() {
    cy.get(homePageLocators.footerMiddleContent).contains(this.homeData.privacyPolicy).click()
    cy.get(homePageLocators.pageTitle).contains(this.homeData.privacyPolicy)
})

When("the user Checks Terms and Conditions", function(){
    cy.get(homePageLocators.footerMiddleContent).contains(this.homeData.termAndCon).click()
    cy.get(homePageLocators.pageTitle).contains(this.homeData.termAndCon)
})

When("the user Checks Get a quote", function() {
    cy.get(homePageLocators.footerQuote).eq(1).contains(this.homeData.quote).click()
    cy.get(homePageLocators.pageTitle).contains(this.servicesData.quoteReq)
})
