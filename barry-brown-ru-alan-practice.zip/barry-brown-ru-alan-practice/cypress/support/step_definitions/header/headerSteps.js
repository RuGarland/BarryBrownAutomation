import { Given, When, Then, DataTable, AfterAll, Background, Before } from "@badeball/cypress-cucumber-preprocessor";
import { homePageLocators } from "../../../pages/homePage";
import { servicesLocators } from "../../../pages/services";

Then("the Header element is visible", function()
{
    cy.get(".header").should("be.visible");
    cy.get(".logo").should("be.visible");
    cy.get("#menu-header").should("be.visible");
});
