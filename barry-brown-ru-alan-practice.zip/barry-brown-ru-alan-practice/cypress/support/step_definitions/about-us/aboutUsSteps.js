import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import { AboutUsPageElements } from "../../../pages/aboutUs";

Given("the user is on the home page", function()
{
    cy.visit("/");
});

When("the user selects the 'about us' link from the nav bar", function()
{
    cy.get("a")
        .contains("About Us")
        .click();
});

Then("the 'about us' page is displayed", function()
{
    cy.get(AboutUsPageElements.pageHeader)
        .invoke("text")
        .should("equal", "About Us");
});


Given("the user is on the 'about us' page", function()
{
    cy.visit("/about-us");
});

When("the user selects the 'services' link from the page content", function()
{
    cy.get("a[title=Services]").click();
});

Then("the 'services' page is displayed", function()
{
    cy.get(".page_title")
        .invoke("text")
        .should("equal", "Services");
});


When("the user selects the 'company video' link", function()
{
    cy.get(".WP_Video_Lightbox").click();
});

Then("a video modal is displayed", function()
{
    cy.get(".pp_pic_holder")
        .then(($element) => 
            {
                expect($element).to.be.visible;
            });
});
