import {Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import { FooterElements } from "../../../pages/footer";

Then("the footer is visible", function()
{
    cy.get(".footer").should("be.visible");
    cy.get(".bottom-footer").should("be.visible");
});
