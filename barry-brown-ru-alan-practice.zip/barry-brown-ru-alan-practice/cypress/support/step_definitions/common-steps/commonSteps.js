/// <reference types="Cypress" />

import { Given, When, Then, Before } from "@badeball/cypress-cucumber-preprocessor";
import { homePageLocators } from "../../../pages/homePage";
import { servicesLocators } from "../../../pages/services";

Before({tags: "@HeadF"}, function() {
    cy.fixture('headerData').then(function(data){
        this.headerData = data;
    });
});

Given("the user is on the {string} page for footer", function (pageName) {
    let path = "";

    switch (String(pageName).toUpperCase().trim()) {
        case "HOME":
            path = "/";
            break;

        case "ABOUT US":
            path = "/about-us";
            break;

        case "SERVICES":
            path = "/services";
            break;

        case "QUOTE REQUEST":
            path = "/quote-request";
            break;

        case "GALLERY":
            path = "/gallery";
            break;

        case "TESTIMONIALS":
            path = "/testimonials";
            break;

        case "WHERE WE ARE":
            path = "/where-we-are";
            break;

        case "CONTACT":
            path = "/contact";
            break;

        default:
            cy.log(`Unknown page name passed to step: \"${pageName}\"`)
            return;
    }

    cy.visit(path);
});

Given("the user is on the {string} page for header", function (pageName) {

    const pageMap = {
        "HOME": { path: "/", menuLabel: "Home" },
        "ABOUT US": { path: "/about-us", menuLabel: "About Us" },
        "SERVICES": { path: "/services", menuLabel: "Services" },
        "QUOTE REQUEST": { path: "/quote-request", menuLabel:  this.headerData.quoteReq },
        "GALLERY": { path: "/gallery", menuLabel: "Gallery" },
        "TESTIMONIALS": { path: "/testimonials", menuLabel: "Testimonials" },
        "WHERE WE ARE": { path: "/where-we-are", menuLabel: "Where We Are" },
        "CONTACT": { path: "/contact", menuLabel: "Contact" }
    };

    const pageDetails = pageMap[String(pageName).toUpperCase().trim()];

    if (!pageDetails) {
        cy.log(`Unknown page name passed to step: "${pageName}"`);
        return;
    }

    if (pageName.includes("Quote Request")) {
        cy.get(servicesLocators.serviceMenu).contains('Services').trigger('mouseover')
        cy.get(servicesLocators.serviceSubMenu).contains(this.headerData.quoteReq).click()
    } else {
        cy.get(servicesLocators.serviceMenu).contains(pageDetails.menuLabel).click();
    }

    if (pageName.includes("Home")) {
        cy.get(homePageLocators.homePageheader).contains(this.headerData.homePageHeader)
    } else {
        cy.get(homePageLocators.pageTitle).contains(pageDetails.menuLabel);
    }
});
