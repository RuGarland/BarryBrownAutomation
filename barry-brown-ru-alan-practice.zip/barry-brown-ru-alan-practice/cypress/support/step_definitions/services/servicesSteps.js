import { Given, When, Then, DataTable, AfterAll, Background, Before, } from "@badeball/cypress-cucumber-preprocessor";
import { homePageLocators } from "../../../pages/homePage";
import { servicesLocators } from "../../../pages/services";

Before({tags: "@ServiceF"}, function() {
    cy.fixture('servicesFixture').then(function(data){
        this.servicesData = data;
    });
});


When("the user selects the services", () => {
    cy.get(servicesLocators.serviceMenu).contains('Services').click()
    cy.get(homePageLocators.pageTitle).contains('Services')
})

When("the user checks the page content", () => {
    cy.get(servicesLocators.serviceContent1).should('be.visible')
    cy.get(servicesLocators.serviceContent2).should('be.visible')
    cy.get(servicesLocators.serviceContent3).should('be.visible')
    cy.get(servicesLocators.serviceContent4).should('be.visible')
    cy.get(servicesLocators.serviceContent5).should('be.visible')
    cy.get(servicesLocators.serviceContent6).should("be.visible")
    cy.get(servicesLocators.serviceContent7).should('be.visible')
    cy.get(servicesLocators.serviceContent8).should('be.visible')
})


When("the user selects the get in touch button", () => {
    cy.get(servicesLocators.serviceTitleContact).click()
    cy.get(homePageLocators.pageTitle).contains("Contact")
})


When("the user selects the get a quote", function() {
    cy.get(servicesLocators.serviceTitleQuote).click()
    cy.get(homePageLocators.pageTitle).contains(this.servicesData.quoteReq)
})


When("the user selects the get a quote from Menu", function() {
    cy.get(servicesLocators.serviceMenu).contains('Services').trigger('mouseover')
    cy.get(servicesLocators.serviceSubMenu).contains(this.servicesData.quoteReq).click()
    cy.get(homePageLocators.pageTitle).contains(this.servicesData.quoteReq)
})


When("the user enters their details for a {string} result", function(result){
        if (result === "possitive") {
            cy.get(servicesLocators.servicesFormField).eq(0).type(this.servicesData.firstName)
            cy.get(servicesLocators.servicesFormField).eq(1).type(this.servicesData.lastName)
            cy.get(servicesLocators.servicesFormField).eq(2).type(this.servicesData.mNumber)
            cy.get(servicesLocators.servicesFormField).eq(3).type(this.servicesData.hNumber)
            cy.get(servicesLocators.servicesFormField).eq(4).type(this.servicesData.text)
        }
        if (result === "negative") {
            cy.get(servicesLocators.servicesFormField).eq(0).type(this.servicesData.invalidNumber)
            cy.get(servicesLocators.servicesFormField).eq(1).type(this.servicesData.invalidNumber)
            cy.get(servicesLocators.servicesFormField).eq(2).type(this.servicesData.numberWord)
            cy.get(servicesLocators.servicesFormField).eq(3).type(this.servicesData.numberWord)
            cy.get(servicesLocators.servicesFormField).eq(4).type(this.servicesData.blankSpace)
        }
        if (result === "blank") {
            cy.get(servicesLocators.servicesFormField).eq(0).type(this.servicesData.blankSpace)
            cy.get(servicesLocators.servicesFormField).eq(1).type(this.servicesData.blankSpace)
            cy.get(servicesLocators.servicesFormField).eq(2).type(this.servicesData.blankSpace)
            cy.get(servicesLocators.servicesFormField).eq(3).type(this.servicesData.blankSpace)
            cy.get(servicesLocators.servicesFormField).eq(4).type(this.servicesData.blankSpace)
        }
})


Then("the user can submit the form on {string}", function(submit){
        if (submit === "possitive") {
            cy.get(servicesLocators.servicesSubmit).submit()
            cy.get(servicesLocators.servicesValidResult).should('be.visible').contains(this.servicesData.validResultComment)
        }
        if (submit === "invalid") {
            cy.get(servicesLocators.servicesSubmit).submit()
            cy.get(servicesLocators.servicesErrorMessage).should('be.visible').contains(this.servicesData.errorMessage)
        }
})
