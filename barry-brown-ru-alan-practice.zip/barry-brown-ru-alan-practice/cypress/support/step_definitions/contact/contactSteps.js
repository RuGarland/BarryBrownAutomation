import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import { ContactPageElements } from "../../../pages/contactPage";

When("the user selects the 'contact' link from the nav bar", function()
{
    cy.get("a")
        .contains("Contact")
        .click();
});

Then("the 'contact' page is displayed", function()
{
    cy.get(ContactPageElements.pageHeader)
        .invoke("text")
        .should("equal", "Contact");
});


Given("the user is on the 'contact' page", function()
{
    cy.visit("/contact");
});

Then("the {string} field is visible", function(fieldName)
{
    switch (fieldName) 
    {
        case "Name":
            cy.get(ContactPageElements.nameField).should("be.visible");
            break;
    
        case "Email":
            cy.get(ContactPageElements.emailField).should("be.visible");
            break;
                
        case "Subject":
            cy.get(ContactPageElements.subjectField).should("be.visible");
            break;

        case "Your message":
            cy.get(ContactPageElements.yourMessageField).should("be.visible");
            break;

        default:
            cy.log(`Unknown field name passed to step: \"${fieldName}\"`)
            break;
    }
});

Then("the 'Submit' button is visible", function()
{
    cy.get(ContactPageElements.submitButton)
        .should("be.visible");
});


Given("all the form fields are visible", function()
{
    cy.get(ContactPageElements.nameField)
        .should("be.visible");

    cy.get(ContactPageElements.emailField)
        .should("be.visible");

    cy.get(ContactPageElements.subjectField)
        .should("be.visible");

    cy.get(ContactPageElements.yourMessageField)
        .should("be.visible");

    cy.get(ContactPageElements.submitButton)
        .should("be.visible");
});

When("all the form fields are empty", function()
{
    cy.get(ContactPageElements.nameField)
        .invoke("text")
        .should("be.empty");

    cy.get(ContactPageElements.emailField)
        .invoke("text")
        .should("be.empty");

    cy.get(ContactPageElements.subjectField)
        .invoke("text")
        .should("be.empty");

    cy.get(ContactPageElements.yourMessageField)
        .invoke("text")
        .should("be.empty");
});

When("the user selects the 'Submit' button", function()
{
    cy.get(ContactPageElements.submitButton)
        .click();
});

Then("the 'contact' form should not be submitted", function()
{
    cy.get(".pretendSuccessMessage")
        .should("not.exist");
});

Then("the 'contact' form is submitted and a confirmation message is shown", function()
{
    cy.wait(4000);
    cy.get(".pretendSuccessMessage")
        .should("exist");
});


Given("all the form fields have content", function()
{
    cy.get(ContactPageElements.nameField)
        .type("Bazza Brownski");

    cy.get(ContactPageElements.emailField)
        .type("hello@what.com");

    cy.get(ContactPageElements.subjectField)
        .type("Testing Contact Form");

    cy.get(ContactPageElements.yourMessageField)
        .type("An example message");
});


When("the {string} field is empty", function(fieldName)
{
    switch (fieldName) 
    {
        case "Name":
            cy.get(ContactPageElements.nameField).clear();
            break;
    
        case "Email":
            cy.get(ContactPageElements.emailField).clear();
            break;
                
        case "Subject":
            cy.get(ContactPageElements.subjectField).clear();
            break;

        case "Your message":
            cy.get(ContactPageElements.yourMessageField).clear();
            break;

        default:
            cy.log(`Unknown field name passed to step: \"${fieldName}\"`)
            break;
    }
});

Then("a validation message for the {string} field should be visible", function(fieldName)
{
    switch (fieldName)
    {
        case "Name":
            cy.get(ContactPageElements.nameFieldRequiredLabel).should("be.visible")
            break;

        case "Email":
            cy.get(ContactPageElements.emailFieldRequiredLabel).should("be.visible")
            break;
                
        case "Subject":
            cy.get(ContactPageElements.subjectFieldRequiredLabel).should("be.visible")
            break;

        case "Your message":
            cy.get(ContactPageElements.yourMessageFieldRequiredLabel).should("be.visible")
            break;

        default:
            cy.log(`Unknown field name passed to step: \"${fieldName}\"`);
            break;
    }
});


When("the user enters a value that is {int} characters long into the {string} field", 
    function(charLen, fieldName)
{
    let fieldSelector = "";

    switch (fieldName) {
        case "Name":
            fieldSelector = ContactPageElements.nameField;
            break;
    
        case "Subject":
            fieldSelector = ContactPageElements.subjectField;
            break;

        case "Your message":
            fieldSelector = ContactPageElements.yourMessageField;
            break;

        default:
            cy.log(`Unknown field name passed to step: \"${fieldName}\"`);
            return;
    }

    cy.get(fieldSelector).clear();
    cy.get(fieldSelector)
        .then(($input) =>
        {
            let generated = generateString(charLen);
            cy.log(`Setting long string on ${fieldName}`);
            $input.val(generated);
        });
});


When("the user enters the value {string} into the 'Email' field", function(emailValue)
{
    cy.get(ContactPageElements.emailField).clear();
    cy.get(ContactPageElements.emailField).type(emailValue);
});





//#region - Helper Methods

function generateString(charLen)
{
    let generated = "";

    for (let i = 0; i < charLen; i++)
        generated += "A";

    return generated;
}

//#endregion - Helper Methods
