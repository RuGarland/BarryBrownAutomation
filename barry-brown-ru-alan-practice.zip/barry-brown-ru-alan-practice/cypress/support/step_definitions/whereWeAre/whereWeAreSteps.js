import { Given, When, Then, DataTable, AfterAll, Background, Before } from "@badeball/cypress-cucumber-preprocessor";
import { homePageLocators } from "../../../pages/homePage";
import { servicesLocators } from "../../../pages/services";
import { whereWeAreLocators } from "../../../pages/whereWeArePage";


Before({tags: "@WhereWeAreF"}, function() {
    cy.fixture('whereWeAreData.json').then(function(data){
       this.whereWeAreData = data;
    });
});

When("the user selects the where we are page", function() {
    cy.get(servicesLocators.serviceMenu).contains(this.whereWeAreData.whereWeAre).click()
    cy.get(homePageLocators.pageTitle).contains(this.whereWeAreData.whereWeAre)
})


When("the user checks the page elements for where we are", function() {
    cy.get(whereWeAreLocators.whereWeAreContent1).should('be.visible')
    cy.get(whereWeAreLocators.whereWeAreContent2).should('be.visible').contains(this.whereWeAreData.address)
    cy.get(whereWeAreLocators.whereWeAreContent2).should('be.visible').contains(this.whereWeAreData.contactNo)
    cy.get(whereWeAreLocators.whereiFrame).should('be.visible')
})

When("the user can open the larger map", function() {
    cy.get(whereWeAreLocators.whereAreMap).invoke('removeAttr', 'target').click({force:true})
    cy.log(this.whereWeAreData.logForMap)
})
