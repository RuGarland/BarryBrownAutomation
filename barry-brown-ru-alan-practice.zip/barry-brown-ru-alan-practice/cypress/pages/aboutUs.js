export const AboutUsPageElements = 
{
    "pageHeader": ".page_title"
}
