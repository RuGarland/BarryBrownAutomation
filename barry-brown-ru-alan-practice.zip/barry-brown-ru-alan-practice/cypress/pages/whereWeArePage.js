export const whereWeAreLocators = {

    whereWeAreContent1: '.content-bar > :nth-child(2)',
    whereWeAreContent2: '.content-bar > :nth-child(3)',
    whereiFrame: 'iframe',

    whereAreMap: 'small > a',
}
