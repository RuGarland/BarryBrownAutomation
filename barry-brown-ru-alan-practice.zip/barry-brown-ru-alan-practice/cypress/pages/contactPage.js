export const ContactPageElements = 
{
    "pageHeader": ".page_title",
    "nameField": "#wpforms-313-field_0",
    "emailField": "#wpforms-313-field_1",
    "subjectField": "#wpforms-313-field_4",
    "yourMessageField": "#wpforms-313-field_2",
    "submitButton": "#wpforms-submit-313",

    //Validation Labels
    "nameFieldRequiredLabel": "#wpforms-313-field_0-error",
    "emailFieldRequiredLabel": "#wpforms-313-field_1-error",
    "subjectFieldRequiredLabel": "#wpforms-313-field_4-error",
    "yourMessageFieldRequiredLabel": "#wpforms-313-field_2-error"
}
