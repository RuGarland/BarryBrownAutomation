export const TestimonialsPageElements = 
{
    "pageHeader": ".page_title",
    "testimonialAuthors": "blockquote span",
    "testimonialQuotes": "blockquote em"
}
