export const servicesLocators = {

    serviceMenu: '.menu-item',
    serviceSubMenu: '.sub-menu',


    serviceContent1: '.content-bar > :nth-child(2)',
    serviceContent2: '.content-bar > :nth-child(4)',
    serviceContent3: '.content-bar > :nth-child(6) > :nth-child(1)',
    serviceContent4: '.content-bar > :nth-child(8)',
    serviceContent5: ':nth-child(10) > :nth-child(1) > span',
    serviceContent6: ':nth-child(14) > :nth-child(1) > span',
    serviceContent7: '.content-bar > :nth-child(16)',
    serviceContent8: ':nth-child(17) > :nth-child(1) > span',

    serviceTitleContact: '[title="Contact"]',
    serviceTitleQuote: '[title="Quote Request"]',

    servicesFormField: '.wpforms-field-medium',
    servicesSubmit: '#wpforms-form-311',
    servicesValidResult: '#wpforms-confirmation-311',
    servicesErrorMessage: '.wpforms-container',
}
