export const homePageLocators = {
    homePageheader: ".header-info > h1",
    homePageImage: ".slide > img",
    homePageAdvice: ".slider-info > h1",
    homePageThink: ".index-fullwidth > h3", 
    
    pageTitle: ".page_title",

    footerContactUs: ".textwidget",
    footerMiddleContent: ".menu-footer-container",
    footerQuote: ".textwidget",

    logoImage: 'a > img',
}
